"""Regressionstest der Rechenkerne (236 Werte, exakt verglichen).

Normaler Aufruf (im Ordner tests):      python baseline.py pruefen
   rechnet mit den Modulen kern_*.py im übergeordneten Ordner und vergleicht mit sollwerte.json
   (die Sollwerte stammen aus der Einzeldatei-Version v7.11.0, zuletzt ergänzt in v8.1.0 um das Feld "tief").
Neue Sollwerte nach einer ABSICHTLICHEN Änderung der Rechnung:   python baseline.py sollwerte
   (überschreibt sollwerte.json mit dem aktuellen Stand – nur wenn die Änderung gewollt ist!)"""
import sys, re, types, json, os, importlib
from unittest import mock
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))

def ser(x):
    if isinstance(x, np.ndarray): return ["nd", [ser(v) for v in x.ravel().tolist()], list(x.shape)]
    if isinstance(x, (np.floating, np.integer)): return x.item()
    if isinstance(x, dict): return {str(k): ser(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [ser(v) for v in x]
    if isinstance(x, float): return repr(x)
    if callable(x): return "<func>"
    return x if isinstance(x, (int, str, bool, type(None))) else repr(x)

def lade_alt(pfad):
    sys.modules['streamlit'] = mock.MagicMock()
    src = open(pfad, encoding="utf-8").read()
    src = re.sub(r'\nif __name__ == "__main__" or True:\n    main\(\)\s*$', '\n', src)
    m = types.ModuleType("alt"); exec(compile(src, pfad, 'exec'), m.__dict__); return m.__dict__

def lade_neu(ordner):
    sys.path.insert(0, ordner)
    ns = {}
    for mod in ("kern_optik", "kern_foucault", "kern_bau", "kern_vergleich"):
        m = importlib.import_module(mod); ns.update({k: v for k, v in m.__dict__.items()})
    return ns

def rechne(ns):
    R = {}
    g = lambda n: ns[n]
    fall = [(200, 1000, 550), (150, 750, 550), (114, 900, 500), (300, 1500, 600)]
    for D, f, lam in fall:
        k = f"{D}/{f}/{lam}"
        R[k+"/berechne"] = g("berechne")(D, f, lam)
        for V in (30, 60, 100, 150, 250):
            R[k+f"/vergr{V}"] = g("berechne_vergr")(D, f, lam, V)
            R[k+f"/qvis{V}"] = g("perceived_quality_exakt")(D, f, lam, V)
            for L, dp in ((None, None), (5, 6), (600, 3), (3500, 2.5)):
                R[k+f"/qvisL{V}{L}"] = g("perceived_quality_exakt")(D, f, lam, V, L=L, d_p=dp)
        R[k+"/vkrit"] = g("v_kritisch")(D, f, lam)
        R[k+"/vkq"] = g("v_krit_aus_qvis")(D, f, lam)
        R[k+"/vhalb"] = g("v_halb_exakt")(D, f, lam)
        R[k+"/qkurve"] = g("perceived_quality_exakt_kurven")(D, f, lam, np.linspace(30, 400, 12), L=600, d_p=3)
        R[k+"/mtfk"] = g("mtf_kurven")(D, f, lam)
        R[k+"/wf"] = g("_wellenfronten")(D, f, lam)
        R[k+"/kennz"] = g("_kennzahlen_von_S")(D, 0.9, 0.2)
        R[k+"/dfang"] = g("d_fang_min")(D, f)
        R[k+"/vmaxh"] = g("v_max_helligkeit")(D, 600.0)
        R[k+"/kurvenN"] = g("kurven_N")(D, lam)
        R[k+"/pfeil"] = g("pfeiltiefe")(D, f)
        R[k+"/tubus"] = g("tubus_aus_okular")(D, f)
        R[k+"/fang"] = g("fangspiegel_rechner")(D, f)
        R[k+"/fang2"] = g("fangspiegel_rechner")(D, f, 60, 250, 12, 0.9, 120, lam, 0, 21, 85)
        R[k+"/fangd"] = g("fangspiegel_d")(D, f)
        R[k+"/qfs"] = g("qvis_kurve_mit_fangspiegel")(D, 0.9, 45.0, lam, np.linspace(30, 300, 9))
        R[k+"/qabs"] = g("qabs")(D, 0.9, 40.0, 150, seeing=1.5, d_pupil=3.0)
        R[k+"/qpup"] = g("qvis_pupille_kurve")(D, 0.9, np.linspace(30, 300, 9), 3.0)
        ga = g("gitterrohr_auto")(D, f, 50, 30, 70, 50, 40, 15, 25, 0)
        R[k+"/gauto"] = ga
        for bau, n in (("zigzag", 3), ("triplex", 6), ("frei", 6)):
            gs = g("gitterrohr_stangen")(ga["h"], ga["d_teil"]/2, n, 1, -25, True, bau)
            R[k+"/gst"+bau] = gs
            R[k+"/gfr"+bau] = g("gitterrohr_freiraum")(ga["h"], ga["d_teil"]/2, gs["dphi"], D, f, ga["feld_halb"], 25)
    R["mtf_para"] = [g("mtf_para")(x) for x in (0.1, 0.5, 0.9)]
    R["csf"] = [g("csf")(x) for x in (1, 5, 10, 30)]
    R["csf_lum"] = [g("csf_lum")(x, L) for x in (1, 5, 10) for L in (0.5, 5, 600)]
    R["seeing"] = g("seeing_mtf")(np.linspace(0, 1, 6), 1.5)
    R["strehl"] = [g("_strehl_exakt")(w) for w in (0.05, 0.2, 0.5)]
    R["foucault_zonen"] = g("foucault_zonen")(200, 5)
    rz = g("foucault_zonen")(200, 5); df = np.array([0.8, 0.5, 0.3, 0.55, 1.0])
    R["foucault_wf"] = g("foucault_wellenfront")(rz, df, 200, 1000, 550)
    R["foucault_kz"] = g("foucault_kennzahlen")(g("foucault_wellenfront")(rz, df, 200, 1000, 550), rz, 200, 550)
    R["beurteilung"] = [g("beurteilung")(s) for s in (0.99, 0.9, 0.5)] if "T" not in ns or True else None
    R["pobj"] = g("planet_objekt")(64)
    R["qkarte"] = g("qabs_karte")(np.array([150., 200, 250]), np.array([0.8, 0.9, 1.0]), 5.0, 150, (200.0, 1.0, 0.0))
    R["qbe"] = g("qabs_breakeven_S")(250, 55, 0.9, 150)
    return R

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "pruefen"
    ref = os.path.join(HERE, "sollwerte.json")
    ns = lade_neu(os.path.dirname(HERE))
    R = {k: ser(v) for k, v in rechne(ns).items()}
    if mode == "sollwerte":
        json.dump(R, open(ref, "w"), sort_keys=True); print(len(R), "Sollwerte geschrieben"); sys.exit(0)
    # Prüffall aus dem Bau (7.11.2026): 14"-TripleX, Aluprofile 1000 mm (gemessen/geliefert, ohne Kürzen)
    ga = ns["gitterrohr_auto"](353, 1420, 78, 30, 70, 50, 45, 15, 25, 400, 6)
    gs = ns["gitterrohr_stangen"](ga["h"], ga["d_teil"] / 2, 6, 1, -25, True, "triplex")
    ok14 = abs(gs["zuschnitt"] - 1000.0) < 1.0
    print("Prüffall 14\" TripleX: Zuschnitt %.1f mm (gemessen 1000 mm): %s" % (gs["zuschnitt"], "OK" if ok14 else "ABWEICHUNG"))
    a = json.load(open(ref))
    bad = [k for k in a if a[k] != R.get(k)]
    print(f"{len(a)} Werte verglichen, {len(bad)} Abweichungen", bad[:10]); sys.exit(1 if (bad or not ok14) else 0)
